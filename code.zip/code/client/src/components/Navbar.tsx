import { Link, useLocation } from "wouter";

export function Navbar() {
  const [location] = useLocation();

  return (
    <header className="bg-card min-h-[70px] px-8 py-4 shadow-md flex flex-col md:flex-row items-center justify-between gap-4 sticky top-0 z-50">
      <Link 
        href="/"
        className="text-xl md:text-2xl font-bold text-primary tracking-wider no-underline hover:opacity-80 transition-opacity"
        data-testid="link-home"
      >
        LeNoobInconnu STUDIO
      </Link>

      <nav className="flex flex-wrap gap-3 md:gap-6 justify-center" data-testid="nav-links">
        <Link 
          href="/"
          className={`
            flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300 no-underline font-medium
            ${location === "/" 
              ? "bg-primary text-primary-foreground font-bold" 
              : "text-foreground hover:bg-primary hover:text-primary-foreground hover:-translate-y-0.5 hover:shadow-[0_5px_15px_rgba(91,95,245,0.4)]"
            }
          `}
          data-testid="nav-home"
        >
          <i className={`fa-solid fa-house ${location === "/" ? "text-primary-foreground" : "text-primary"}`}></i>
          <span>Accueil</span>
        </Link>

        <Link 
          href="/outils"
          className={`
            flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300 no-underline font-medium
            ${location === "/outils" 
              ? "bg-primary text-primary-foreground font-bold" 
              : "text-foreground hover:bg-primary hover:text-primary-foreground hover:-translate-y-0.5 hover:shadow-[0_5px_15px_rgba(91,95,245,0.4)]"
            }
          `}
          data-testid="nav-tools"
        >
          <i className={`fa-solid fa-chart-simple ${location === "/outils" ? "text-primary-foreground" : "text-primary"}`}></i>
          <span>Creator Studio</span>
        </Link>

        <a
          href="https://discord.gg/PbntRm5sNy"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300 no-underline font-medium text-foreground hover:bg-primary hover:text-primary-foreground hover:-translate-y-0.5 hover:shadow-[0_5px_15px_rgba(91,95,245,0.4)]"
          data-testid="nav-discord"
        >
          <i className="fa-brands fa-discord text-primary"></i>
          <span>Discord</span>
        </a>

        <a
          href="#"
          className="flex items-center gap-2 px-3 py-2 rounded-md transition-all duration-300 no-underline font-medium text-foreground hover:bg-primary hover:text-primary-foreground hover:-translate-y-0.5 hover:shadow-[0_5px_15px_rgba(91,95,245,0.4)]"
          data-testid="nav-serveur"
        >
          <i className="fa-solid fa-gamepad text-primary"></i>
          <span>Serveur MC</span>
        </a>
      </nav>
    </header>
  );
}
