import type { Tool } from "@shared/schema";

interface ToolCardProps {
  tool: Tool;
}

const statusConfig = {
  available: {
    label: "Disponible",
    icon: "fa-check-circle",
    bgColor: "rgba(90, 166, 103, 0.2)",
    textColor: "#5aa667",
  },
  development: {
    label: "En développement",
    icon: "fa-code",
    bgColor: "rgba(243, 156, 18, 0.2)",
    textColor: "#f39c12",
  },
  maintenance: {
    label: "Maintenance",
    icon: "fa-tools",
    bgColor: "rgba(231, 76, 60, 0.2)",
    textColor: "#e74c3c",
  },
};

export function ToolCard({ tool }: ToolCardProps) {
  const status = statusConfig[tool.status as keyof typeof statusConfig] || statusConfig.available;

  return (
    <div 
      className="bg-card p-8 rounded-[15px] shadow-md border border-card-border transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lg flex flex-col h-full"
      data-testid={`card-tool-${tool.id}`}
    >
      <div className="flex flex-col items-center text-center flex-1">
        <i 
          className={`${tool.icon} text-[2.5rem] text-primary mb-4`}
          data-testid={`icon-tool-${tool.id}`}
        ></i>
        
        <h3 
          className="text-2xl font-bold text-foreground mb-3"
          data-testid={`title-tool-${tool.id}`}
        >
          {tool.name}
        </h3>
        
        <p 
          className="text-base text-muted-foreground mb-6 flex-1"
          data-testid={`description-tool-${tool.id}`}
        >
          {tool.description}
        </p>
      </div>

      <div 
        className="flex items-center justify-center gap-2 px-5 py-3 rounded-lg font-semibold text-[0.95rem]"
        style={{
          backgroundColor: status.bgColor,
          color: status.textColor,
        }}
        data-testid={`status-tool-${tool.id}`}
      >
        <i className={`fa-solid ${status.icon}`}></i>
        <span>{status.label}</span>
      </div>
    </div>
  );
}
