import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { ToolCard } from "@/components/ToolCard";
import type { Tool } from "@shared/schema";

export default function Tools() {
  const { data: tools, isLoading, error } = useQuery<Tool[]>({
    queryKey: ["/api/tools"],
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="px-5 py-10 flex flex-col items-center text-center gap-12">
        <div className="max-w-6xl w-full">
          <h1 
            className="text-5xl md:text-6xl font-bold text-foreground mb-3"
            data-testid="text-page-title"
          >
            Outils pour Créateurs YouTube
          </h1>
          
          <p 
            className="text-xl text-muted-foreground mb-10"
            data-testid="text-page-subtitle"
          >
            Des outils puissants pour développer votre chaîne YouTube
          </p>
        </div>

        <div className="max-w-6xl w-full">
          {isLoading && (
            <div className="flex flex-col items-center gap-4 py-20">
              <div className="animate-spin">
                <i className="fa-solid fa-circle-notch text-5xl text-primary" data-testid="icon-loading"></i>
              </div>
              <p className="text-lg text-muted-foreground" data-testid="text-loading">
                Chargement des outils...
              </p>
            </div>
          )}

          {error && (
            <div className="bg-card p-10 rounded-[15px] shadow-md border border-card-border">
              <i className="fa-solid fa-exclamation-triangle text-5xl text-destructive mb-4" data-testid="icon-error"></i>
              <p className="text-lg text-muted-foreground" data-testid="text-error">
                Erreur lors du chargement des outils. Veuillez réessayer plus tard.
              </p>
            </div>
          )}

          {!isLoading && !error && tools && tools.length === 0 && (
            <div className="bg-card p-10 rounded-[15px] shadow-md border border-card-border">
              <i className="fa-solid fa-tools text-5xl text-muted-foreground mb-4" data-testid="icon-empty"></i>
              <p className="text-lg text-muted-foreground" data-testid="text-empty">
                Aucun outil disponible pour le moment
              </p>
            </div>
          )}

          {!isLoading && !error && tools && tools.length > 0 && (
            <div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              data-testid="grid-tools"
            >
              {tools.map((tool) => (
                <ToolCard key={tool.id} tool={tool} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
