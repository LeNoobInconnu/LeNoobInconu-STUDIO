import { Link } from "wouter";
import { Navbar } from "@/components/Navbar";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="px-5 py-10 flex flex-col items-center text-center gap-12">
        <div className="max-w-4xl w-full">
          <h1 
            className="text-5xl md:text-6xl font-bold text-foreground mb-4"
            data-testid="text-welcome"
          >
            Bienvenue au Studio
          </h1>
          
          <p 
            className="text-xl text-muted-foreground mb-10"
            data-testid="text-subtitle"
          >
            Découvrez nos outils pour créateurs YouTube
          </p>

          <Link 
            href="/outils"
            className="inline-flex items-center gap-3 px-9 py-4 rounded-lg text-lg font-bold bg-primary text-primary-foreground shadow-[0_8px_20px_rgba(91,95,245,0.5)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_12px_25px_rgba(91,95,245,0.7)] no-underline"
            data-testid="button-view-tools"
          >
            <i className="fa-solid fa-chart-simple text-xl"></i>
            <span>Voir les Outils</span>
          </Link>
        </div>

        <div className="bg-card p-10 rounded-[15px] shadow-md border border-card-border max-w-4xl w-full">
          <h2 
            className="text-3xl font-bold text-primary mb-4"
            data-testid="text-about-title"
          >
            À Propos
          </h2>
          <p 
            className="text-lg text-muted-foreground leading-relaxed"
            data-testid="text-about-description"
          >
            LeNoobInconnu STUDIO propose une collection d'outils conçus pour aider les créateurs YouTube débutants à développer leur chaîne. Nos outils sont régulièrement mis à jour et améliorés pour répondre à vos besoins.
          </p>
        </div>
      </div>
    </div>
  );
}
