import { type User, type InsertUser, type Tool, type InsertTool } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllTools(): Promise<Tool[]>;
  getTool(id: string): Promise<Tool | undefined>;
  createTool(tool: InsertTool): Promise<Tool>;
  updateTool(id: string, tool: Partial<InsertTool>): Promise<Tool | undefined>;
  deleteTool(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private tools: Map<string, Tool>;

  constructor() {
    this.users = new Map();
    this.tools = new Map();
    this.seedTools();
  }

  private seedTools() {
    const defaultTools: InsertTool[] = [
      {
        name: "Générateur de Miniatures",
        description: "Créez des miniatures YouTube accrocheuses en quelques clics avec nos modèles personnalisables",
        icon: "fa-solid fa-image",
        status: "development",
      },
      {
        name: "Tableau de Bord Analytics",
        description: "Suivez vos statistiques YouTube en temps réel avec des graphiques détaillés et des insights",
        icon: "fa-solid fa-chart-line",
        status: "available",
      },
      {
        name: "Planificateur de Vidéos",
        description: "Organisez votre calendrier de publication et ne manquez jamais une date importante",
        icon: "fa-solid fa-clock",
        status: "available",
      },
      {
        name: "Optimiseur de Titres",
        description: "Générez des titres accrocheurs optimisés pour le SEO et l'engagement",
        icon: "fa-solid fa-heading",
        status: "development",
      },
      {
        name: "Générateur de Tags",
        description: "Trouvez les meilleurs tags pour améliorer la découvrabilité de vos vidéos",
        icon: "fa-solid fa-tags",
        status: "available",
      },
      {
        name: "Test A/B Miniatures",
        description: "Comparez différentes miniatures pour déterminer laquelle performe le mieux",
        icon: "fa-solid fa-flask",
        status: "maintenance",
      },
      {
        name: "Assistant de Script",
        description: "Obtenez de l'aide pour écrire des scripts vidéo engageants et structurés",
        icon: "fa-solid fa-file-lines",
        status: "development",
      },
      {
        name: "Gestionnaire de Commentaires",
        description: "Gérez et répondez à vos commentaires YouTube depuis une interface centralisée",
        icon: "fa-solid fa-comments",
        status: "available",
      },
      {
        name: "Analyseur SEO",
        description: "Analysez et optimisez vos vidéos pour améliorer leur référencement",
        icon: "fa-solid fa-search",
        status: "available",
      },
      {
        name: "Suivi de Monétisation",
        description: "Suivez vos revenus et performances de monétisation en un coup d'œil",
        icon: "fa-solid fa-dollar-sign",
        status: "development",
      },
    ];

    defaultTools.forEach((tool) => {
      const id = randomUUID();
      this.tools.set(id, { ...tool, id });
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllTools(): Promise<Tool[]> {
    return Array.from(this.tools.values());
  }

  async getTool(id: string): Promise<Tool | undefined> {
    return this.tools.get(id);
  }

  async createTool(insertTool: InsertTool): Promise<Tool> {
    const id = randomUUID();
    const tool: Tool = { ...insertTool, id };
    this.tools.set(id, tool);
    return tool;
  }

  async updateTool(id: string, updates: Partial<InsertTool>): Promise<Tool | undefined> {
    const tool = this.tools.get(id);
    if (!tool) return undefined;

    const updatedTool: Tool = { ...tool, ...updates };
    this.tools.set(id, updatedTool);
    return updatedTool;
  }

  async deleteTool(id: string): Promise<boolean> {
    return this.tools.delete(id);
  }
}

export const storage = new MemStorage();
